const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");
let currentInput = "";
let currentOperator = "";
let firstOperand = 0;
let isResultDisplayed = false;

buttons.forEach((button) => {
    button.addEventListener("click", () => handleButtonClick(button.textContent));
});

function handleButtonClick(value) {
    if (isResultDisplayed) {
        currentInput = "";
        isResultDisplayed = false;
    }

    if (Number.isInteger(parseInt(value)) || value === "") {
        currentInput = currentInput === "" ? value : currentInput + value;
    } else if (value === "C") {
        clearCalculator();
    } else if (value === "=") {
        evaluateExpression();
    } else {
        if (currentOperator !== "") {
            evaluateExpression();
        }
        currentOperator = value;
        firstOperand = parseFloat(currentInput);
        currentInput = "";
    }
    updateDisplay();
}

function clearCalculator() {
    currentInput = "";
    currentOperator = "";
    firstOperand = 0;
}

function evaluateExpression() {
    const secondOperand = parseFloat(currentInput);
    switch (currentOperator) {
        case "+":
            firstOperand += secondOperand;
            break;
        case "-":
            firstOperand -= secondOperand;
            break;
        case "*":
            firstOperand *= secondOperand;
            break;
        case "/":
            firstOperand /= secondOperand;
            break;
    }
    currentInput = firstOperand.toString();
    currentOperator = "";
    isResultDisplayed = true;
}

function updateDisplay() {
    if (currentOperator) {
        display.textContent = firstOperand + " " + currentOperator + " " + currentInput;
    } else {
        display.textContent = currentInput;
    }
}
